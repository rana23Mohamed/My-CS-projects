alert("Hello!");
// Select color input
const gridColor =document.querySelector('#colorPicker');
// Select size input
const Height=document.querySelector('#inputHeight');
const Width=document.querySelector('#inputWidth');
const grid =document.querySelector('#pixelCanvas');
const button= document.querySelector('#sizePicker');
// make fragment to build the rows and columns on
const fragment = document.createDocumentFragment();
//making submit button able to prevent submitting action from occurance and make user able to repeat the action
button.addEventListener('submit',function(evt){
    evt.preventDefault();
    console.log("AlertOnClick");
    makeGrid();
});
// creating a function to choose the colour of the grid
function clickMe(type) {
    const color = gridColor.value;
    //to recieve event
    event.target.style.backgroundColor = color;
}
  // When size is submitted by the user, call makeGrid()
function makeGrid() {
    // Your code goes here!
    grid.innerHTML=null
  // forming nested for loop to make the grids
  //forming rows
  for (x = 0; x < Height.value; x++) {
    const square = document.createElement('tr');

    for (y = 0; y < Width.value; y++) {
      const squareTwo = document.createElement('td');
      square.append(squareTwo);
    }
      square.addEventListener('click', clickMe);
      fragment.append(square);
    }
    // to get the fragment into the Dom
    grid.append(fragment);
  }
